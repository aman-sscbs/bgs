<?php
/**
 * Footer for Tokoo
 */
$footer_version = tokoo_get_footer_version();

get_footer( $footer_version ); ?>
